#ifndef ASSIGNMENT9_VC_FOREACH_H
#define ASSIGNMENT9_VC_FOREACH_H

void vc_foreach(int *tab, int length, void(*f)(int));

#endif //ASSIGNMENT9_VC_FOREACH_H
