#ifndef ASSIGNMENT9_VC_IS_SORT_H
#define ASSIGNMENT9_VC_IS_SORT_H

int vc_is_sort(int *tab, int length, int(*f)(int, int));

#endif //ASSIGNMENT9_VC_IS_SORT_H
