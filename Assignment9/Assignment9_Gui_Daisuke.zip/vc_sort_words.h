#ifndef ASSIGNMENT9_VC_SORT_WORDS_H
#define ASSIGNMENT9_VC_SORT_WORDS_H

void vc_sort_words(char **words);

#endif //ASSIGNMENT9_VC_SORT_WORDS_H
