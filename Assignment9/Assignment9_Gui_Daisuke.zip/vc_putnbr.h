#ifndef ASSIGNMENT9_VC_PUTNBR_H
#define ASSIGNMENT9_VC_PUTNBR_H


void vc_putnbr(int nb);

#endif //ASSIGNMENT9_VC_PUTNBR_H
