#ifndef ASSIGNMENT9_VC_ANY_H
#define ASSIGNMENT9_VC_ANY_H

int vc_any(char **tab, int(*f)(char*));

#endif //ASSIGNMENT9_VC_ANY_H
