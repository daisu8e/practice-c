#ifndef ASSIGNMENT9_VC_COUNT_IF_H
#define ASSIGNMENT9_VC_COUNT_IF_H

int vc_count_if(char **tab, int(*f)(char*));

#endif //ASSIGNMENT9_VC_COUNT_IF_H
