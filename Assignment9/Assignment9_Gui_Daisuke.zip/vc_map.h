#ifndef ASSIGNMENT9_VC_MAP_H
#define ASSIGNMENT9_VC_MAP_H

int *vc_map(int *tab, int length, int(*f)(int));

#endif //ASSIGNMENT9_VC_MAP_H
